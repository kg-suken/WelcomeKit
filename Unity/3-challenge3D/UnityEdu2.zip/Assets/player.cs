using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour
{
    public Transform transform;
    private Rigidbody rigid;
    public bool zimenn;
    // Start is called before the first frame update
    void Start()
    {
        transform.position = new Vector3(0,4f,0);
        rigid = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey(KeyCode.D)){
            transform.Translate(0.03f,0,0);
        }
        if(Input.GetKey(KeyCode.A)){
            transform.Translate(-0.03f,0,0);
        }
        if(Input.GetKey(KeyCode.W)){
            transform.Translate(0f,0,0.03f);
        }
        if(Input.GetKey(KeyCode.S)){
            transform.Translate(-0,0,-0.03f);
        }
        if(Input.GetKey(KeyCode.Space)){
            if(zimenn){
            rigid.AddForce(transform.up * 500);
            zimenn = false;
            }
        }
    }
    void OnCollisionEnter(Collision col){
        if(col.gameObject.tag == "zimenn"){
            zimenn = true;
        }
    }
}
